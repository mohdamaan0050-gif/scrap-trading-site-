import PageHeader from '@/components/ui/PageHeader';
import IndustryGrid from '@/components/sections/IndustryGrid';
import CTABand from '@/components/sections/CTABand';
import SectionHeading from '@/components/ui/SectionHeading';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Industries served',
  description:
    'We handle waste for FMCG, pharma, automotive, textile, construction, electronics, warehousing and sugar units across UP, Uttarakhand and NCR.',
  path: '/industries',
});

export default function IndustriesPage() {
  return (
    <>
      <PageHeader
        title="We price waste by what it is, not by who made it."
        lede="Every industry throws off a different mix. These are the sectors we work in most, and what we usually lift from each."
      />

      <section className="shell py-20 lg:py-28">
        <IndustryGrid />
      </section>

      <section className="border-t border-steel-faint bg-board py-20 lg:py-24">
        <div className="shell">
          <SectionHeading
            title="Where we operate"
            lede="Saharanpur is our base. Regular routes run to Haridwar, Roorkee, Muzaffarnagar, Meerut, Ghaziabad and the wider NCR belt. For large lots and auction clearances we travel further into UP and Uttarakhand."
          />
        </div>
      </section>

      <CTABand />
    </>
  );
}
