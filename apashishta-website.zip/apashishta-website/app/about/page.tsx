import PageHeader from '@/components/ui/PageHeader';
import CTABand from '@/components/sections/CTABand';
import Reveal from '@/components/ui/Reveal';
import StatsStrip from '@/components/sections/StatsStrip';
import { certifications, company, fullAddress } from '@/content/site';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'About us',
  description:
    'Apashishta Vyapar Sanstha is a Saharanpur-based waste trading, collection and recycling firm serving industrial units across western UP and Uttarakhand.',
  path: '/about',
});

export default function AboutPage() {
  return (
    <>
      <PageHeader
        title="A scrap business run like a supply chain."
        lede="We started at the weighbridge and built everything else around it — the bins, the manpower, the manifests and the monthly file your auditor asks for."
      />

      <StatsStrip />

      <section className="shell grid gap-14 py-20 lg:grid-cols-12 lg:py-28">
        <div className="lg:col-span-7">
          <Reveal>
            <div className="max-w-prose space-y-6 text-lg leading-relaxed text-steel">
              <p>
                Apashishta Vyapar Sanstha buys and handles industrial waste from
                a base in Saharanpur. What began as lot-wise scrap purchase from
                a handful of local units now runs as a full waste yard service:
                collection rounds inside the plant, segregation, baling,
                weighment, dispatch to registered recyclers, and the paperwork
                that ties the whole chain together.
              </p>
              <p>
                Most plants do not have a scrap problem. They have a scrap
                paperwork problem. A trader lifts material, the weight is
                disputed, payment drags, and at audit there is no certificate to
                show where any of it went. We built the firm to close all four
                of those gaps at once.
              </p>
              <p>
                The firm is run by {company.proprietor}, who is on site for
                pricing decisions and lot inspections himself. That is
                deliberate. Rates in this trade move week to week, and a rate
                quoted by someone who has not seen the material is a rate that
                gets revised at the gate.
              </p>
            </div>
          </Reveal>
        </div>

        <aside className="lg:col-span-5 lg:pl-8">
          <Reveal delay={0.08}>
            <div className="rounded-data border border-steel-faint p-7">
              <h2 className="font-display text-lg font-bold text-forest">
                Firm details
              </h2>
              <dl className="mt-6 space-y-4 text-[0.95rem]">
                <div className="rule pt-4 first:border-0 first:pt-0">
                  <dt className="text-steel-light">Proprietor</dt>
                  <dd className="mt-1 font-semibold text-forest">
                    {company.proprietor}
                  </dd>
                </div>
                <div className="rule pt-4">
                  <dt className="text-steel-light">Registered office</dt>
                  <dd className="mt-1 leading-relaxed text-forest">{fullAddress}</dd>
                </div>
                <div className="rule pt-4">
                  <dt className="text-steel-light">Working hours</dt>
                  <dd className="mt-1 text-forest">{company.hours}</dd>
                </div>
                {certifications.map((c) => (
                  <div key={c.label} className="rule pt-4">
                    <dt className="text-steel-light">{c.label}</dt>
                    <dd className="tabular mt-1 text-forest">{c.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </Reveal>
        </aside>
      </section>

      <CTABand />
    </>
  );
}
