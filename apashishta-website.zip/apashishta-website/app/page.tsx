import Link from 'next/link';
import Hero from '@/components/sections/Hero';
import StatsStrip from '@/components/sections/StatsStrip';
import ServiceGrid from '@/components/sections/ServiceGrid';
import IndustryGrid from '@/components/sections/IndustryGrid';
import ProcessTimeline from '@/components/sections/ProcessTimeline';
import WhyGrid from '@/components/sections/WhyGrid';
import Testimonials from '@/components/sections/Testimonials';
import CTABand from '@/components/sections/CTABand';
import SectionHeading from '@/components/ui/SectionHeading';
import Accordion from '@/components/ui/Accordion';
import { faqs, services } from '@/content/site';
import { faqSchema } from '@/lib/jsonld';

export default function HomePage() {
  return (
    <>
      <Hero />
      <StatsStrip />

      <section className="shell py-20 lg:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading
            title="What we take off your hands"
            lede="Eight services that cover a plant's waste from the bin at the machine to the recycler's gate."
          />
          <Link
            href="/services"
            className="font-semibold text-brand underline underline-offset-4 hover:text-brand-dark"
          >
            All services
          </Link>
        </div>
        <div className="mt-12">
          <ServiceGrid items={services.slice(0, 6)} />
        </div>
      </section>

      <section className="border-y border-steel-faint bg-board py-20 lg:py-28">
        <div className="shell">
          <SectionHeading
            title="How a lot moves"
            lede="From the first site walk to the compliance pack at month end, the sequence never changes."
          />
          <ProcessTimeline />
        </div>
      </section>

      <section className="shell py-20 lg:py-28">
        <SectionHeading
          title="Plants we work with"
          lede="Different industries, different waste. We grade and price each stream on its own terms."
        />
        <div className="mt-12">
          <IndustryGrid />
        </div>
      </section>

      <section className="border-y border-steel-faint bg-board py-20 lg:py-28">
        <div className="shell">
          <SectionHeading
            title="Why plants stay with us"
            lede="Most scrap problems are not about price. They are about paperwork, payment and whether the truck turns up."
          />
          <div className="mt-12">
            <WhyGrid />
          </div>
        </div>
      </section>

      <section className="shell py-20 lg:py-28">
        <SectionHeading title="What our customers say" />
        <Testimonials />
      </section>

      <section className="border-t border-steel-faint py-20 lg:py-28">
        <div className="shell grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <SectionHeading
              title="Questions we get asked"
              lede="If yours is not here, call and ask."
            />
          </div>
          <div className="lg:col-span-8">
            <Accordion items={faqs.slice(0, 5)} />
            <Link
              href="/faq"
              className="mt-8 inline-block font-semibold text-brand underline underline-offset-4 hover:text-brand-dark"
            >
              All questions
            </Link>
          </div>
        </div>
      </section>

      <CTABand />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </>
  );
}
