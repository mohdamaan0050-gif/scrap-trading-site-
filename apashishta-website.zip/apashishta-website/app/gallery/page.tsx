import PageHeader from '@/components/ui/PageHeader';
import Gallery from '@/components/sections/Gallery';
import CTABand from '@/components/sections/CTABand';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Gallery',
  description:
    'The yard, the bins, the bales and the fleet — photographs of Apashishta Vyapar Sanstha at work.',
  path: '/gallery',
});

export default function GalleryPage() {
  return (
    <>
      <PageHeader
        title="The yard, the bales and the fleet."
        lede="Photographs from our own sites and customer plants. Select any image to see it larger."
      />
      <section className="shell py-20 lg:py-28">
        <Gallery />
      </section>
      <CTABand />
    </>
  );
}
