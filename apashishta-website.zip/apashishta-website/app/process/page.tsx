import PageHeader from '@/components/ui/PageHeader';
import ProcessTimeline from '@/components/sections/ProcessTimeline';
import CTABand from '@/components/sections/CTABand';
import SectionHeading from '@/components/ui/SectionHeading';
import Reveal from '@/components/ui/Reveal';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Sustainability process',
  description:
    'Our six-step process: site audit, rate card, collection, weighment, recycling through registered processors, and a monthly compliance pack.',
  path: '/process',
});

const diverted = [
  { stream: 'Metals', route: 'Graded, baled and sent to furnaces and rolling mills' },
  { stream: 'Paper and carton', route: 'Baled and sent to paper mills for pulping' },
  { stream: 'Plastics', route: 'Sorted by polymer, granulated by registered processors' },
  { stream: 'E-waste', route: 'Dismantled only by CPCB-authorised recyclers' },
  { stream: 'Hazardous streams', route: 'Moved under manifest to SPCB-authorised handlers' },
];

export default function ProcessPage() {
  return (
    <>
      <PageHeader
        title="Sorted at source, weighed in the open, recycled on record."
        lede="Landfill is the expensive option and the one that leaves no paper trail. Our process is built to keep material moving into recovery instead."
      />

      <section className="shell py-20 lg:py-28">
        <SectionHeading
          title="The six steps"
          lede="Same order every time, whether it is a one-off lot or an annual contract."
        />
        <ProcessTimeline />
      </section>

      <section className="border-t border-steel-faint bg-board py-20 lg:py-28">
        <div className="shell">
          <SectionHeading
            title="Where the material actually goes"
            lede="Diversion only counts if you can name the destination."
          />
          <div className="mt-12 overflow-hidden rounded-data border border-steel-faint bg-white">
            <table className="w-full text-left">
              <caption className="sr-only">
                Waste streams and their recycling routes
              </caption>
              <thead>
                <tr className="border-b border-steel-faint bg-board">
                  <th scope="col" className="px-6 py-4 font-display text-sm font-bold text-forest">
                    Stream
                  </th>
                  <th scope="col" className="px-6 py-4 font-display text-sm font-bold text-forest">
                    Recovery route
                  </th>
                </tr>
              </thead>
              <tbody>
                {diverted.map((row) => (
                  <tr key={row.stream} className="border-b border-steel-faint last:border-0">
                    <th scope="row" className="px-6 py-4 font-semibold text-forest">
                      {row.stream}
                    </th>
                    <td className="px-6 py-4 text-steel">{row.route}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Reveal>
            <p className="mt-8 max-w-prose leading-relaxed text-steel">
              At month end you get a recovery statement: tonnage lifted by
              stream, where each stream went, and the certificates for anything
              that legally needs one.
            </p>
          </Reveal>
        </div>
      </section>

      <CTABand />
    </>
  );
}
