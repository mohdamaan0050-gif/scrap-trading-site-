import PageHeader from '@/components/ui/PageHeader';
import CTABand from '@/components/sections/CTABand';
import Reveal from '@/components/ui/Reveal';
import { testimonials } from '@/content/site';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Testimonials',
  description:
    'What stores heads, EHS managers and purchase teams say about working with Apashishta Vyapar Sanstha.',
  path: '/testimonials',
});

export default function TestimonialsPage() {
  return (
    <>
      <PageHeader
        title="What the people who sign the contract say."
        lede="Stores heads, EHS managers and purchase teams across UP and Uttarakhand."
      />

      <section className="shell py-20 lg:py-28">
        <ul className="grid gap-px bg-steel-faint md:grid-cols-2">
          {testimonials.map((t, i) => (
            <li key={t.quote} className="bg-white">
              <Reveal delay={Math.min(i, 4) * 0.05} className="h-full">
                <figure className="flex h-full flex-col justify-between p-8 lg:p-10">
                  <blockquote className="font-display text-lg font-semibold leading-snug text-forest sm:text-xl">
                    {t.quote}
                  </blockquote>
                  <figcaption className="mt-8 text-[0.95rem] text-steel">
                    {t.role}, {t.place}
                  </figcaption>
                </figure>
              </Reveal>
            </li>
          ))}
        </ul>
      </section>

      <CTABand />
    </>
  );
}
