import PageHeader from '@/components/ui/PageHeader';
import Accordion from '@/components/ui/Accordion';
import CTABand from '@/components/sections/CTABand';
import { faqs } from '@/content/site';
import { faqSchema } from '@/lib/jsonld';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'FAQ',
  description:
    'Minimum quantities, how rates are set, payment timing, hazardous waste, documentation, manpower and the areas we cover.',
  path: '/faq',
});

export default function FaqPage() {
  return (
    <>
      <PageHeader
        title="The questions purchase teams ask first."
        lede="Straight answers on quantity, rates, payment and paperwork."
      />

      <section className="shell max-w-4xl py-20 lg:py-28">
        <Accordion items={faqs} />
      </section>

      <CTABand />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
    </>
  );
}
