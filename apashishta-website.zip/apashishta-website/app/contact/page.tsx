import { Clock, Mail, MapPin, Phone } from 'lucide-react';
import PageHeader from '@/components/ui/PageHeader';
import ContactForm from '@/components/sections/ContactForm';
import MapEmbed from '@/components/sections/MapEmbed';
import { company, fullAddress } from '@/content/site';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Contact',
  description:
    'Call 8868061839 or send an enquiry. Apashishta Vyapar Sanstha, Anand Nagar, Saharanpur 247001, Uttar Pradesh.',
  path: '/contact',
});

export default function ContactPage() {
  return (
    <>
      <PageHeader
        title="Send us a list. We will send back a rate."
        lede="Materials, rough weights and your location are enough to start. We usually come and see the lot within the week."
      />

      <section className="shell grid gap-14 py-20 lg:grid-cols-12 lg:py-28">
        <div className="lg:col-span-7">
          <ContactForm />
        </div>

        <aside className="lg:col-span-5 lg:pl-8">
          <h2 className="font-display text-display-sm text-forest">
            Or reach us directly
          </h2>
          <ul className="mt-8 space-y-6">
            <li className="flex gap-4">
              <Phone aria-hidden className="mt-1 h-5 w-5 shrink-0 text-brand" />
              <div>
                <p className="text-sm text-steel-light">Phone</p>
                <a
                  href={`tel:${company.phoneIntl}`}
                  className="tabular font-display text-lg font-bold text-forest hover:text-brand"
                >
                  {company.phone}
                </a>
              </div>
            </li>
            <li className="flex gap-4">
              <Mail aria-hidden className="mt-1 h-5 w-5 shrink-0 text-brand" />
              <div>
                <p className="text-sm text-steel-light">Email</p>
                <a
                  href={`mailto:${company.email}`}
                  className="break-all font-semibold text-forest hover:text-brand"
                >
                  {company.email}
                </a>
              </div>
            </li>
            <li className="flex gap-4">
              <MapPin aria-hidden className="mt-1 h-5 w-5 shrink-0 text-brand" />
              <div>
                <p className="text-sm text-steel-light">Office</p>
                <p className="leading-relaxed text-forest">{fullAddress}</p>
              </div>
            </li>
            <li className="flex gap-4">
              <Clock aria-hidden className="mt-1 h-5 w-5 shrink-0 text-brand" />
              <div>
                <p className="text-sm text-steel-light">Open</p>
                <p className="text-forest">{company.hours}</p>
              </div>
            </li>
          </ul>
        </aside>
      </section>

      <section className="shell pb-20 lg:pb-28">
        <MapEmbed />
      </section>
    </>
  );
}
