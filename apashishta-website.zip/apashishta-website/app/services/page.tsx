import PageHeader from '@/components/ui/PageHeader';
import ServiceGrid from '@/components/sections/ServiceGrid';
import CTABand from '@/components/sections/CTABand';
import { services } from '@/content/site';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Services',
  description:
    'Scrap trading, waste collection and segregation, recycling, e-waste handling, plant waste contracts, transport, compliance documentation and auction purchase.',
  path: '/services',
});

export default function ServicesPage() {
  return (
    <>
      <PageHeader
        title="Everything from the bin at the machine to the recycler's gate."
        lede="Take one service or hand over the whole waste yard. The rate card and the paperwork work the same way either way."
      />

      <section className="shell py-20 lg:py-28">
        <ServiceGrid items={services} detailed />
      </section>

      <CTABand />
    </>
  );
}
