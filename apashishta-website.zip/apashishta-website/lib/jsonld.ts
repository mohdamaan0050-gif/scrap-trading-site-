import { company, faqs, services, siteUrl, fullAddress } from '@/content/site';

/** Organization + LocalBusiness schema, rendered once in the root layout. */
export const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  '@id': `${siteUrl}/#organization`,
  name: company.name,
  alternateName: company.shortName,
  description: `${company.discipline} for industrial and commercial units across north India.`,
  url: siteUrl,
  telephone: company.phoneIntl,
  email: company.email,
  founder: { '@type': 'Person', name: company.proprietor },
  foundingDate: company.founded,
  address: {
    '@type': 'PostalAddress',
    streetAddress: `${company.address.line1}, ${company.address.line2}`,
    addressLocality: company.address.city,
    addressRegion: company.address.state,
    postalCode: company.address.postalCode,
    addressCountry: company.address.countryCode,
  },
  geo: {
    '@type': 'GeoCoordinates',
    latitude: company.geo.lat,
    longitude: company.geo.lng,
  },
  openingHours: 'Mo-Sa 09:00-19:00',
  areaServed: ['Uttar Pradesh', 'Uttarakhand', 'Delhi NCR'],
  slogan: company.tagline,
  makesOffer: services.map((s) => ({
    '@type': 'Offer',
    itemOffered: { '@type': 'Service', name: s.title, description: s.summary },
  })),
};

export const faqSchema = {
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: faqs.map((f) => ({
    '@type': 'Question',
    name: f.q,
    acceptedAnswer: { '@type': 'Answer', text: f.a },
  })),
};

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: `${siteUrl}${item.path}`,
    })),
  };
}

export const addressForSchema = fullAddress;
