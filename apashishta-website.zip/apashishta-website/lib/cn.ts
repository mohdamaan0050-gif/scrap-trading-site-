/** Tiny class-name joiner. Keeps bundle size down — no clsx dependency. */
export function cn(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(' ');
}
