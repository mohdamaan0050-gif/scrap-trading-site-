import {
  Building2,
  CircuitBoard,
  ClipboardCheck,
  Cog,
  Cpu,
  Factory,
  FileCheck2,
  Gavel,
  IndianRupee,
  Leaf,
  Pill,
  Recycle,
  Scale,
  ScrollText,
  ShieldCheck,
  Shirt,
  ShoppingBasket,
  Timer,
  Trash2,
  Truck,
  Warehouse,
  Wheat,
  type LucideIcon,
} from 'lucide-react';

/**
 * Named icon registry so content files can reference icons as plain strings
 * and stay free of JSX.
 */
export const iconMap: Record<string, LucideIcon> = {
  Building2,
  CircuitBoard,
  ClipboardCheck,
  Cog,
  Cpu,
  Factory,
  FileCheck2,
  Gavel,
  IndianRupee,
  Leaf,
  Pill,
  Recycle,
  Scale,
  ScrollText,
  ShieldCheck,
  Shirt,
  ShoppingBasket,
  Timer,
  Trash2,
  Truck,
  Warehouse,
  Wheat,
};

export function getIcon(name: string): LucideIcon {
  return iconMap[name] ?? Recycle;
}
