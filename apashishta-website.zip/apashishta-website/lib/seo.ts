import type { Metadata } from 'next';
import { company, siteUrl } from '@/content/site';

type PageMetaInput = {
  title: string;
  description: string;
  path: string;
};

/** Builds consistent per-page metadata, including canonical URL and OG tags. */
export function pageMeta({ title, description, path }: PageMetaInput): Metadata {
  const url = `${siteUrl}${path}`;
  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      title: `${title} | ${company.name}`,
      description,
      url,
      siteName: company.name,
      locale: 'en_IN',
      type: 'website',
      images: [{ url: `${siteUrl}/og.svg`, width: 1200, height: 630, alt: company.name }],
    },
    twitter: {
      card: 'summary_large_image',
      title: `${title} | ${company.name}`,
      description,
    },
  };
}
